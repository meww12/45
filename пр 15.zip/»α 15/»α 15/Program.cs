﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace пр_15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("колво комплексных чисел {0}",
                Complex.HowMany1());
            Complex[] a;
            Complex d;
            a = new Complex[3];
            a[0] = new Complex(-1, 1);
            a[1] = new Complex(2, 5);
            a[2] = new Complex(3, 0);
            Console.WriteLine("колво комплексных чисел {0}",    Complex.HowMany1());
            d = new Complex();
            for (int i = 0; i < a.Length; i++)
            {
                a[i].PrintComp();
                d = d + a[i];
            }
            Console.WriteLine("Сумма равна"); d.PrintComp();
            Console.WriteLine("Модуль суммы равен {0:0.00}", d.Abs());
            Console.WriteLine("колва комплексных чисел {0}", Complex.HowMany1());
            Console.ReadKey();
        }
    }

}       







